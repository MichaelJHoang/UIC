package com.example.workingcodingmania;
/////////////////////////////////////////////////////////////////////////////////////////////
//								Working, Loving, Programming								//
/////////////////////////////////////////////////////////////////////////////////////////////
//	Type of Program:				Game						            				//
//	File Author:					Jeremy Robles											//
//	File Name:						Puzzle_Catalog.java										//
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
import java.util.ArrayList;

public class Puzzle_Catalog {
    int credibility;
    int pythonCredibility, cppCredibility, assemblyCredibility, sqlCredibility, javaCredibility, cCredibility;
    ArrayList<Puzzle> puzzleArrayList;
    int puzzlesFound, puzzlesSolved;

    public Puzzle_Catalog()
    {
        puzzleArrayList = new ArrayList<>();
    }

    public void updateInfo()
    {
        String language;
        credibility = 0;
        pythonCredibility = 0;
        cppCredibility = 0;
        assemblyCredibility = 0;
        sqlCredibility = 0;
        javaCredibility = 0;
        cCredibility = 0;
        puzzlesFound = puzzleArrayList.size();
        puzzlesSolved = 0;

        for (Puzzle p : puzzleArrayList)
        {
            if (p.isComplete)
                puzzlesSolved++;

            language = p.language();
            if (language.equals("C++"))
                cppCredibility += p.currentCredibility;
            else if (language.equals("Python"))
                pythonCredibility += p.currentCredibility;
            else if (language.equals("Assembly"))
                assemblyCredibility+= p.currentCredibility;
            else if (language.equals("Java"))
                javaCredibility+= p.currentCredibility;
            else if (language.equals("C"))
                cCredibility+= p.currentCredibility;
            else if (language.equals("SQL"))
                sqlCredibility+= p.currentCredibility;
        }
        credibility = cppCredibility + pythonCredibility + assemblyCredibility + javaCredibility + cCredibility + sqlCredibility;
    }
}//end public class Puzzle_Catalog
