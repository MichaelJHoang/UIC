package com.example.workingcodingmania;

/////////////////////////////////////////////////////////////////////////////////////////////
//								Working, Loving, Programming								//
/////////////////////////////////////////////////////////////////////////////////////////////
//	Type of Program:				Game						            				//
//	File Author:					Jeremy Robles											//
//	File Name:						main.java												//
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class jeremy_MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jeremy_activity_main);
    }

    public void buttonTestFillCode(View v)
    {
        Intent intent = new Intent
                (getApplicationContext(), PuzzleActivity.class);
        intent.putExtra("PUZZLE_ID", R.array.Puzzle10);
        startActivityForResult(intent, 100);
    }

    public void buttonMultiChoice(View v)
    {
        Intent intent = new Intent
                (getApplicationContext(), PuzzleActivity.class);
        intent.putExtra("PUZZLE_ID", R.array.Puzzle12);
        startActivityForResult(intent, 100);
    }

    public void clipboardButton(View v)
    {
        Intent intent = new Intent
                (getApplicationContext(), PuzzleCatalogActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        int credibilityReward = data.getIntExtra("CREDIBILITY_REWARD", 0);

        if (resultCode == RESULT_OK)
        {
            Toast.makeText(getApplicationContext(),"You received " + credibilityReward + " credibility from the puzzle!", Toast.LENGTH_LONG)
                    .show();
        }//end if (resultCode == RESULT_OK)
        else if (resultCode == RESULT_CANCELED)
        {
            Toast.makeText(getApplicationContext(),"Puzzle was to difficult, huh?", Toast.LENGTH_LONG)
                    .show();
        }//end else (resultCode == RESULT_CANCELED)
        else
        {
            Toast.makeText(getApplicationContext(),"ERROR RESULTCODE", Toast.LENGTH_LONG)
                    .show();
        }
    }//end protected void onActivityResult(int requestCode, int resultCode, Intent data)
}
