package com.example.workingcodingmania;

import java.util.ArrayList;

public class Choice extends DialogText {
    private String text;
    private int index;
    private String filepath; // consequence of choosing

    @Override
    public String getText() {
        return text;
    }

    @Override
    public void setText(String e) {
        text = e;
    }

    public void setFilepath(String e) {
        filepath = e;
    }

    public String getFilepath() {
        return filepath;
    }

    @Override
    public int getTextType() {
        return 2;
    }

    @Override
    public String getNextContent() {
        return text;
    }

}
