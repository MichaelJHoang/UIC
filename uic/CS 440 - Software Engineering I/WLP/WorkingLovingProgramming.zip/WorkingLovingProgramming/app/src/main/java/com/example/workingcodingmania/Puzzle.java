package com.example.workingcodingmania;

/////////////////////////////////////////////////////////////////////////////////////////////
//								Working, Loving, Programming								//
/////////////////////////////////////////////////////////////////////////////////////////////
//	Type of Program:				Game						            				//
//	File Author:					Jeremy Robles											//
//	File Name:						Puzzle.java												//
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////

public abstract class Puzzle
{
    int stringID_title, //String of puzzle title
        stringID_description, //String of puzzle description
        stringID_code,  //The code represented as a string
        stringID_hint,  //Hints provided by the character
        stringID_explanation,   //The explanation of solution
        initialCredibility, //The initial value (difficulty) of puzzle
        currentCredibility, //The current reward value of puzzle (will initially be equal initialCredibility)
        puzzleID;

    boolean isComplete;

    String title, //String of puzzle title
           description, //String of puzzle description
           hint,  //Hints provided by the character
           code,  //The code represented as a string
           explanation;   //The explanation of solution

    Puzzle()
    {
        isComplete = false;
        //stringID_title = ;
    }
    
    String language()
    {
        if (title.contains("Puzzle 1")) {
            return "C++";
        }
        else if (title.contains("Puzzle 2")) {
            return "Python";
        }
        else if (title.contains("Puzzle 3")) {
            return "Assembly";
        }
        else if (title.contains("Puzzle 4")) {
            return "SQL";
        }
        else if (title.contains("Puzzle 5")) {
            return "C";
        }
        else if (title.contains("Puzzle 6")) {
            return "Java";
        }
        else
            return "Language";
    }
}//end public abstract class Puzzle
