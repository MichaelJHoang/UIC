package com.example.workingcodingmania;

/////////////////////////////////////////////////////////////////////////////////////////////
//								Working, Loving, Programming								//
/////////////////////////////////////////////////////////////////////////////////////////////
//	Type of Program:				Game						            				//
//	File Author:					Jeremy Robles											//
//	File Name:						PuzzleActivity.java												//
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PuzzleActivity extends AppCompatActivity {
    public static final String TAG = "PuzzleActivity";
    public Button quitButton;   //Button to quit
    public ImageView characterPortrait_imageView; //Portrait for the character
    public EditText code_editText;  //EditText that holds the code
    public TextView credibility_textView; //TextView that holds the credibility scores
    public TextView description_textView;   //TextView that holds the puzzle description
    public String baseCredibility;
    public Button optionButtons[] = new Button[4]; //4 buttons for the options for multiple choice

    String userSubmission;  //The string of the user's code obtained from the editText in fill-in-the-code

    public Puzzle puzzle;   //Puzzle data from XML is stored here
    public int puzzleID;    //Puzzle ID (string-array ID from XML)
    int puzzleType; //0 - Fill in the blanks, 1 - output, 2 - spot the error

    //Media objects to play background music and sound effects
    protected MediaPlayer bgmPlayer;
    protected SoundPool sp;
    protected int[] soundIDs = new int[8];

    // shows the system bars by removing all the flags
    // except for the ones that make the content appear
    // under the system bars
    private void showSystemUI()
    {
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void hideSystemUI()
    {
        View decorView = getWindow().getDecorView();

        // enables regular immersive mode
        // for "lean back" mode, remove flag_immersive
        // or for sticky, replace with immersive_sticky
        decorView.setSystemUiVisibility(
                // set the content to appear under the system bars so
                // that the content does not resize when the system
                // bars hide and show
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // hide the nav and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        WindowManager.LayoutParams attr = getWindow().getAttributes();
        attr.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        getWindow().setAttributes(attr);
    }

    @Override
    public void onWindowFocusChanged (boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus)
            hideSystemUI();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.i(TAG, "In onCreate");

        super.onCreate(savedInstanceState);

        setTheme(R.style.AppTheme);
        puzzleID = getIntent().getIntExtra("PUZZLE_ID", 0);
        initPuzzle(puzzleID);

        Transition fade = new Fade();
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);
        getWindow().setExitTransition(fade);
        getWindow().setEnterTransition(fade);

        //Match layout with Fill-in-the-Code puzzle
        if (puzzleType == 0) {
            setContentView(R.layout.activity_puzzle_fillinthecode);
            code_editText = findViewById(R.id.code_PuzzleFillInTheCode_editText);
            credibility_textView = findViewById(R.id.credibilityStatus_PuzzleFillInTheCode_textView);
            description_textView = findViewById(R.id.description_PuzzleFillInTheCode_extView);
            characterPortrait_imageView = findViewById(R.id.charPortrait_fillinthecode_imageView);
        }

        //Match layout with Multiple choice puzzle
        else {
            setContentView(R.layout.activity_puzzle_multichoice);

            characterPortrait_imageView = findViewById(R.id.charPortrait_multichoice_imageView);
            code_editText = findViewById(R.id.code_PuzzleFillInTheCode_editText);
            credibility_textView = findViewById(R.id.credibilityStatus_PuzzleFillInTheCode_textView);
            description_textView = findViewById(R.id.description_PuzzleFillInTheCode_extView);
            optionButtons[0] = findViewById(R.id.optionA_PuzzleMultiChoice_button);
            optionButtons[1] = findViewById(R.id.optionB_PuzzleMultiChoice_button);
            optionButtons[2] = findViewById(R.id.optionC_PuzzleMultiChoice_button);
            optionButtons[3] = findViewById(R.id.optionD_PuzzleMultiChoice_button);

            //User should not be able to edit the textbox
            code_editText.setFocusable(false);

            optionButtons[0].setText(((Puzzle_MultiChoice)puzzle).optionA);
            optionButtons[1].setText(((Puzzle_MultiChoice)puzzle).optionB);
            optionButtons[2].setText(((Puzzle_MultiChoice)puzzle).optionC);
            optionButtons[3].setText(((Puzzle_MultiChoice)puzzle).optionD);
        }
        //gameData = Generator.DEBUG.initGameData();


        //Common code for all layouts
        code_editText.setText(puzzle.code);
        baseCredibility = "/" + Integer.toString(puzzle.initialCredibility);
        credibility_textView.setText(Integer.toString(puzzle.currentCredibility) + baseCredibility);
        description_textView.setText(puzzle.description);
        setCharPortrait();
    }//end protected void onCreate(Bundle savedInstanceState)

    @Override
    protected void onStart()
    {
        Log.i(TAG, "In onStart");
        super.onStart();
        sp = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        soundIDs[0] = sp.load(this, R.raw.sfx_menu_decide, 1);
        soundIDs[1] = sp.load(this, R.raw.sfx_menu_decide_l, 1);
        soundIDs[2] = sp.load(this, R.raw.sfx_menu_decide_s, 1);
        soundIDs[3] = sp.load(this, R.raw.sfx_menu_decline, 1);
        soundIDs[4] = sp.load(this, R.raw.sfx_menu_finish, 1);
        soundIDs[5] = sp.load(this, R.raw.sfx_menu_highlight, 1);
        soundIDs[6] = sp.load(this, R.raw.sfx_puzzle_solution_incorrect, 1);
        soundIDs[7] = sp.load(this, R.raw.sfx_puzzle_solution_correct, 1);

        bgmPlayer = MediaPlayer.create(this,R.raw.music_theme_puzzle);
        bgmPlayer.setLooping(true);
        bgmPlayer.start();
    }//end protected void onStart()

    @Override
    protected void onPause()
    {
        Log.i(TAG, "In onPause");
        bgmPlayer.pause();
        super.onPause();
    }//end protected void onPause()

    @Override
    protected void onResume()
    {
        Log.i(TAG, "In onResume");
        super.onResume();
        bgmPlayer.seekTo(0);
        bgmPlayer.start();
    }//end protected void onResume()

    @Override
    protected void onStop()
    {
        Log.i(TAG, "In onStop");
        sp.release();
        sp = null;
        bgmPlayer.stop();
        bgmPlayer.reset();
        bgmPlayer.release();
        bgmPlayer = null;
        super.onStop();
    }//end protected void onStop()

    @Override
    protected void onDestroy()
    {
        Log.i(TAG, "In onDestroy");
        super.onDestroy();
    }//end protected void onDestroy()

    private void setCharPortrait()
    {
        if (puzzleID == R.array.Puzzle10)
            characterPortrait_imageView.setImageResource(R.drawable.character_python_icon_neutral);
        else
            characterPortrait_imageView.setImageResource(R.drawable.character_sql_icon_neutral);

        /*
        if (puzzle.language().equals("C++"))
            characterPortrait_imageView.setImageResource();
        else if (puzzle.language().equals("Python"))
            characterPortrait_imageView.setImageResource();

        else if (puzzle.language().equals("Assembly"))
            characterPortrait_imageView.setImageResource();

        else if (puzzle.language().equals("SQL"))
            characterPortrait_imageView.setImageResource();

        else if (puzzle.language().equals("Java"))
            characterPortrait_imageView.setImageResource();

        else if (puzzle.language().equals("C"))
            characterPortrait_imageView.setImageResource();

        else
            characterPortrait_imageView.setImageResource();
        */
    }//end private void setCharPortrait()

    public void initPuzzle(int stringArrayID)
    {
        String puzzleInfo[] = getResources().getStringArray(stringArrayID);

        puzzleType = Integer.parseInt(puzzleInfo[0]);
        if (puzzleType == 0)
        {
            puzzle = new Puzzle_FillInTheCode();
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[0] = puzzleInfo[7];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[1] = puzzleInfo[8];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[2] = puzzleInfo[9];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[3] = puzzleInfo[10];
        }
        else
        {
            puzzle = new Puzzle_MultiChoice();
            ((Puzzle_MultiChoice) puzzle).optionA = puzzleInfo[7];
            ((Puzzle_MultiChoice) puzzle).optionB = puzzleInfo[8];
            ((Puzzle_MultiChoice) puzzle).optionC = puzzleInfo[9];
            ((Puzzle_MultiChoice) puzzle).optionD = puzzleInfo[10];
            ((Puzzle_MultiChoice) puzzle).solution_index = Integer.parseInt(puzzleInfo[11]);
        }

        puzzle.puzzleID = stringArrayID;
        puzzle.title = puzzleInfo[1];
        puzzle.description = puzzleInfo[2];
        puzzle.code = puzzleInfo[3];
        puzzle.hint = puzzleInfo[4];
        puzzle.explanation = puzzleInfo[5];
        puzzle.initialCredibility = Integer.parseInt(puzzleInfo[6]);
        puzzle.currentCredibility = puzzle.initialCredibility;
    }//end public void initPuzzle(int stringArrayID)

    public void onClickQuit(View v)
    {
        quitPuzzle();
    }//end public void onClickQuit

    public void onClickSubmit(View v)
    {
        if (isCorrectSolution())
        {
            //Play "correct" SFX
            sp.play(soundIDs[7], 1, 1, 1, 0, 1);
            Toast.makeText(PuzzleActivity.this,"That's correct! You got " + puzzle.currentCredibility + " credibility!", Toast.LENGTH_LONG)
                    .show();
            Intent intent = getIntent();
            intent.putExtra("CREDIBILITY_REWARD", puzzle.currentCredibility);
            setResult(RESULT_OK, intent);
            finish();
        }
        else
        {
            //Play "incorrect" SFX
            sp.play(soundIDs[6], 1, 1, 1, 0, 1);
            int pointDeduction = puzzle.initialCredibility / 10;
            int minimumReward = puzzle.initialCredibility / 4;  //The player's credibility reward cannot be below this value

            //Only deduct points if the current reward is greater than 1/4 of the original reward
            if (puzzle.currentCredibility > minimumReward)
            {

                Toast.makeText(PuzzleActivity.this,"That's incorrect! -" + pointDeduction + " credibility...", Toast.LENGTH_LONG)
                        .show();
                puzzle.currentCredibility -= pointDeduction;
                credibility_textView.setText(Integer.toString(puzzle.currentCredibility) + baseCredibility);
            }
            else
            {

                Toast.makeText(PuzzleActivity.this,"That's incorrect!", Toast.LENGTH_LONG)
                        .show();
            }
        }
    }//end public void onClickSubmit

    public void onClickReset(View v)
    {
        //Play "highlight" SFX
        sp.play(soundIDs[5], 1, 1, 1, 0, 1);
        code_editText.setText(puzzle.code);
    }//end public void onClickReset

    //For Fill-in-the-Code puzzles. Gets the string from the editText box, converts it into a "simple" string, and checks if it is equal to any of the solutions.
    private boolean isCorrectSolution()
    {
        userSubmission = code_editText.getText().toString();
        String simpleSubmission = userSubmission.replaceAll("[\\n\\t ]","").toLowerCase();
        Puzzle_FillInTheCode p = (Puzzle_FillInTheCode)puzzle;

        return (simpleSubmission.equals(p.possibleSlns[0]) ||
                simpleSubmission.equals(p.possibleSlns[1]) ||
                simpleSubmission.equals(p.possibleSlns[2]) ||
                simpleSubmission.equals(p.possibleSlns[3]) );
    }//end private boolean isCorrectSolution


    public void onClickButton(View v)
    {
        int viewID = v.getId();
        int solution_index = ((Puzzle_MultiChoice)puzzle).solution_index;

        if ((viewID == R.id.optionA_PuzzleMultiChoice_button && solution_index == 0)||
                (viewID == R.id.optionB_PuzzleMultiChoice_button && solution_index == 1)||
                (viewID == R.id.optionC_PuzzleMultiChoice_button && solution_index == 2)||
                (viewID == R.id.optionD_PuzzleMultiChoice_button && solution_index == 3))
        {
            //Play "correct" SFX
            sp.play(soundIDs[7], 1, 1, 1, 0, 1);
            Toast.makeText(PuzzleActivity.this,"That's correct! You got " + puzzle.currentCredibility + " credibility!", Toast.LENGTH_LONG)
                    .show();
            Intent intent = getIntent();
            intent.putExtra("CREDIBILITY_REWARD", puzzle.currentCredibility);
            setResult(RESULT_OK, intent);
            finish();
        }
        else
        {
            //Play "incorrect" SFX
            sp.play(soundIDs[6], 1, 1, 1, 0, 1);
            int pointDeduction = puzzle.initialCredibility / 10;
            int minimumReward = puzzle.initialCredibility / 4;  //The player's credibility reward cannot be below this value

            //Only deduct points if the current reward is greater than 1/4 of the original reward
            if (puzzle.currentCredibility > minimumReward)
            {

                Toast.makeText(PuzzleActivity.this,"That's incorrect! -" + pointDeduction + " credibility...", Toast.LENGTH_LONG)
                        .show();
                puzzle.currentCredibility -= pointDeduction;
                credibility_textView.setText(Integer.toString(puzzle.currentCredibility) + baseCredibility);
            }
            else
            {

                Toast.makeText(PuzzleActivity.this,"That's incorrect!", Toast.LENGTH_LONG)
                        .show();
            }

        }
    }//end public void onClickButton

    public void quitPuzzle()
    {
        //Play "decline" SFX
        sp.play(soundIDs[3], 1, 1, 1, 0, 1);
        Intent intent = getIntent();
        intent.putExtra("CREDIBILITY_REWARD", 0);
        setResult(RESULT_CANCELED, intent);
        finish();
    }//end  public void quitPuzzle()

    @Override
    public void onBackPressed()
    {
        quitPuzzle();
        super.onBackPressed();
    }//end public void onBackPressed()
}//end public abstract class PuzzleActivity extends AppCompatActivity
