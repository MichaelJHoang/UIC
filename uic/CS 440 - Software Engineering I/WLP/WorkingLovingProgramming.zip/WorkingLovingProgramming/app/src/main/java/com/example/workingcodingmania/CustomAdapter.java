package com.example.workingcodingmania;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class CustomAdapter extends BaseAdapter
{
    // array filled with all the background references
    int imageID[] = {
            R.drawable.barphoto,
            R.drawable.cafephoto,
            R.drawable.officephoto,
            R.drawable.parkphoto
    };

    private Context context;

    // constructor
    public CustomAdapter(Context context)
    {
        this.context = context;
    }

    @Override
    public int getCount()
    {
        return imageID.length;
    }

    public Object getItem(int position)
    {
        return null;
    }

    public long getItemId(int position)
    {
        return 0;
    }

    // create a new image view for each item referenced by the adapter
    public View getView (int position, View convertView, ViewGroup parent)
    {
        ImageView imageView;

        if (convertView == null)
        {
            imageView = new ImageView(this.context);
            imageView.setLayoutParams(new GridView.LayoutParams(500, 500));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        }
        else
        {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(imageID[position]);

        return imageView;
    }
}