package com.example.workingcodingmania;

import android.app.Activity ;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Random;

public class shin_MainActivity extends Activity {


    // shows the system bars by removing all the flags
    // except for the ones that make the content appear
    // under the system bars
    private void showSystemUI()
    {
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void hideSystemUI()
    {
        View decorView = getWindow().getDecorView();

        // enables regular immersive mode
        // for "lean back" mode, remove flag_immersive
        // or for sticky, replace with immersive_sticky
        decorView.setSystemUiVisibility(
                // set the content to appear under the system bars so
                // that the content does not resize when the system
                // bars hide and show
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // hide the nav and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        WindowManager.LayoutParams attr = getWindow().getAttributes();
        attr.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        getWindow().setAttributes(attr);
    }


    @Override
    public void onWindowFocusChanged (boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus)
            hideSystemUI();
    }


    public static final String TAG = "shin_MainActivity";
    ImageView character;
    ImageView background;
    TextView dialogbox;
    TextView charname;
    LinearLayout listchoiceview;
    Button choice1;
    Button choice2;
    ArrayList<Dialog> dialogsList;

    private int savingfile;
    private int index;
    private int textIndex;

    //Media objects to play background music and sound effects
    protected MediaPlayer bgmPlayer;
    protected SoundPool sp;
    protected int[] soundIDs = new int[8];
    int songIDs[] = {
            R.raw.einsteins_ribbon,
            R.raw.maemi_aaron_myhouse,
            R.raw.cafa_kikushima_ootayuki,
            R.raw.junya_nakanao_elfinforest,
            R.raw.ein_syabon
    };

    private void parseXML(int fileid) {
        Log.i("parseXML", "Start to parse XML");
        XmlPullParserFactory parserFactory;
        try {
            parserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserFactory.newPullParser();
            Resources res = getResources();
            InputStream is = res.openRawResource(fileid); // CHANGE SO THAT FILE NAME IS NOT HARDCODED
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(is, null);
            Log.i("parseXML", is.toString() + " opening");
            processParsing(parser);

        } catch (XmlPullParserException e) {
            Log.e("XmlPullParserException", "File could not be opened.");
        } catch (IOException e) {
        }
    }

//    private Dialog _processDialogTag(XmlPullParser parser) {
//
//
//    }
//
//    private ArrayList<Dialog> _processTag(XmlPullParser parser, ArrayList<Dialog> dialogs) throws IOException, XmlPullParserException  {
//            final String tagName = parser.getName();
//            switch (tagName) {
//                case "Dialog":
//                    parser.next();
//                    Dialog lastDialog = _processDialogTag(parser);
//                    dialogs.add(lastDialog);
//
//                    break;
//
//            }
//
//    }
//
//    private ArrayList<Dialog> _processParsing(XmlPullParser parser, ArrayList<Dialog> dialogs) throws IOException, XmlPullParserException {
//        int event = parser.getEventType();
//        switch (event) {
//    //        case XmlPullParser.START_TAG:
//    //            dialogs = _processTag(parser, dialogs);
//    //            break;
//            case XmlPullParser.END_DOCUMENT:
//                return dialogs;
//            default:
//                dialogs = _processTag(parser, dialogs);
//        }
//        parser.next();
//        return _processParsing(parser, dialogs);
//    }

    /**
     * TODO : change this to a recursive function (maybe) probably not
     * @param parser
     * @throws IOException
     * @throws XmlPullParserException
     */
    private void processParsing(XmlPullParser parser) throws IOException, XmlPullParserException{
        Log.i("processParsing", "Call to processParsing");
        ArrayList<Dialog> dialogs = new ArrayList<>();
        int eventType = parser.getEventType();
        Dialog currentDialog = null;
        Choice currentChoice = null;
        int choiceMode = 0;
        int numChoices = 0;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String eltName = null;

            switch (eventType) {
                case XmlPullParser.START_TAG:
                    eltName = parser.getName();

                    if(choiceMode > 0 && numChoices < 2) {
                        System.out.println(eltName);

                        if ("Choice".equals(eltName)) {
                            currentChoice = new Choice();
                            choiceMode++;
                        } else if ("Text".equals(eltName) && currentChoice != null) {
                            String text = parser.nextText();
                            System.out.println(text + " button text");
                            currentChoice.setText(text);
                            choiceMode++;
                        } else if ("Path".equals(eltName) && currentChoice != null) {

                            String fp = parser.nextText();
                            System.out.println(fp + " fp text");
                            currentChoice.setFilepath(fp);
                            choiceMode++;
                            numChoices++;
                            currentDialog.textList.add(currentChoice);
                            Log.i("Choice", "Added new choice");
                        }

                        if (numChoices >= 2) {
                            numChoices = 0;
                            choiceMode = 0;
                        }
                    }

                    else if ("Dialog".equals(eltName)) {
                        Log.i("processParsing", "start Dialog tag");
                        currentDialog = new Dialog();
                        dialogs.add(currentDialog);
                    } else if ("Close".equals(eltName)) {
                        String fileidentifier =  parser.nextText();
                        savingfile = getResId(fileidentifier, R.raw.class);

                        System.out.println(savingfile + " new saving file : " + fileidentifier);
                    }
                    else if (currentDialog != null && currentDialog.textList != null) {
                        if ("Text".equals(eltName)) {
                            String text = parser.nextText();
                            DialogText textphrase = new DialogText();
                            textphrase.setText(text);
                            currentDialog.textList.add(textphrase);
                            Log.i("processParsing", "add " + currentDialog.textList.get(currentDialog.textList.size() - 1));
                        }
                        if ("Choices".equals(eltName)){
                            Log.i("Choices", "entered");
                            choiceMode = 1;
                        }

                    }
                    else if (currentDialog != null) {
                        if ("CharacterIMG".equals(eltName)) {
                            currentDialog.charImg = parser.nextText();
                            Log.i("processParsing", currentDialog.charImg);

                        } else if ("name".equals(eltName)) {
                            currentDialog.charname = parser.nextText();
                            Log.i("processParsing", currentDialog.charname);
                        } else if ("DialogTexts".equals(eltName)) {
                            currentDialog.textList = new ArrayList<DialogText>();
                        }
                    }
                    break;
            }

            eventType = parser.next();
            // Log.i("processParsing", Integer.toString(eventType) +" " + Integer.toString(XmlPullParser.END_DOCUMENT));

        }
        Log.i("processParsing", "done parsing");
        dialogsList = dialogs;
    }

    private void proceedDialog()
    {
        if (dialogsList != null && dialogbox != null) {
            Log.i("BgClicklistener", "enter if");
            if (index < dialogsList.size()) {
                Dialog d = dialogsList.get(index);
                // new dialog
                if (textIndex == 0 || textIndex >= d.textList.size() ) {
                    int resID = getApplicationContext().getResources().getIdentifier(d.charImg , "drawable", getPackageName());
                    character.setImageResource(resID);
                    charname.setText(d.charname);
                } // dialog is in the middle
                if (textIndex < d.textList.size()){
                    DialogText text = d.textList.get(textIndex);
                    if (text.getTextType() == 2 ) {
                        if (textIndex < d.textList.size()-1){
                            DialogText text2 = d.textList.get(textIndex + 1);
                            choice1.setText(text.getText());
                            choice2.setText(text2.getText());
                            listchoiceview.setVisibility(View.VISIBLE);
                        }

                    } else if (text.getTextType() == 1){
                        dialogbox.setText(d.textList.get(textIndex).getText());
                        textIndex++;
                    }

                } else { //dialog is ending
                    index++;
                    textIndex = 0;
                    proceedDialog();
                }

            } else {
                Log.i("done", "end");
                Intent intent = new Intent();
                setResult(Activity.RESULT_OK, intent);
                intent.putExtra("fid", savingfile);

                finish();
            }
        }
    }

    private class BgClicklistener implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            Log.i("BgClicklistener", "clicked");
            proceedDialog();
        }

    }

    public int getResId(String resName, Class<?> c) {
        try {
            Field idField = c.getDeclaredField(resName);
            return idField.getInt(idField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    private class ButtonClicklistener implements Button.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            Log.i("ButtonClicklistener", "clicked");
            // first check if chocies are visible, second check that the current DialogText at textIndex is indeed a Choice
            if (listchoiceview.getVisibility() == View.VISIBLE) {
                Dialog d = dialogsList.get(index);
                switch (v.getId()) {
                    case R.id.choice1:
                        Choice c = (Choice) d.textList.get(textIndex);
                        String fp = c.getFilepath();
                        int fid = getResId(fp, R.raw.class);
                        resetDialog(fid);
                        break;
                    case R.id.choice2:
                        c = (Choice) d.textList.get(textIndex+1);
                        fp = c.getFilepath();
                        fid = getResId(fp, R.raw.class);
                        resetDialog(fid);
                        break;
                    default:
                        Log.i("Button not chosen", "clicked");
                        break;
                }
            }
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("onCreate", "Start onCreate callback");
        int fi = R.raw.data;

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.getInt("fileid") > 0)
                fi = extras.getInt("fileid");


        }



        resetDialog(fi);

    }


    @Override
    protected void onStart()
    {
        Log.i(TAG, "In onStart");
        super.onStart();
        Random random = new Random();
        sp = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        soundIDs[0] = sp.load(this, R.raw.sfx_menu_decide, 1);
        soundIDs[1] = sp.load(this, R.raw.sfx_menu_decide_l, 1);
        soundIDs[2] = sp.load(this, R.raw.sfx_menu_decide_s, 1);
        soundIDs[3] = sp.load(this, R.raw.sfx_menu_decline, 1);
        soundIDs[4] = sp.load(this, R.raw.sfx_menu_finish, 1);
        soundIDs[5] = sp.load(this, R.raw.sfx_menu_highlight, 1);
        soundIDs[6] = sp.load(this, R.raw.sfx_puzzle_solution_incorrect, 1);
        soundIDs[7] = sp.load(this, R.raw.sfx_puzzle_solution_correct, 1);

        bgmPlayer = MediaPlayer.create(this,songIDs[random.nextInt(songIDs.length)]);
        bgmPlayer.setLooping(true);
        bgmPlayer.start();
    }//end protected void onStart()

    @Override
    protected void onPause()
    {
        Log.i(TAG, "In onPause");
        bgmPlayer.pause();
        super.onPause();
    }//end protected void onPause()

    @Override
    protected void onResume()
    {
        Log.i(TAG, "In onResume");
        super.onResume();
        bgmPlayer.seekTo(0);
        bgmPlayer.start();
    }//end protected void onResume()

    @Override
    protected void onStop()
    {
        Log.i(TAG, "In onStop");
        sp.release();
        sp = null;
        bgmPlayer.stop();
        bgmPlayer.reset();
        bgmPlayer.release();
        bgmPlayer = null;
        super.onStop();
    }//end protected void onStop()

    @Override
    protected void onDestroy()
    {
        Log.i(TAG, "In onDestroy");
        super.onDestroy();
    }//end protected void onDestroy()

    private void resetDialog(int fileid) {
        setContentView(R.layout.shin_dialogue);
        character = (ImageView) findViewById(R.id.character);
        background = (ImageView) findViewById(R.id.bg_image);
        dialogbox = (TextView) findViewById(R.id.dialog_text);
        charname = (TextView) findViewById(R.id.dialog_name);
        listchoiceview = (LinearLayout) findViewById(R.id.flContent);
        choice1 = (Button) findViewById(R.id.choice1);
        choice2 = (Button) findViewById(R.id.choice2);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            if (extras.getInt("backgroundImage") > 0)
            {
                int bgint =  extras.getInt("backgroundImage");
                background.setBackgroundResource(bgint);
            }
        }

        textIndex = 0;
        index = 0;
        parseXML(fileid);
        proceedDialog();
        BgClicklistener bgclicklis = new BgClicklistener();
        ButtonClicklistener bclicklis = new ButtonClicklistener();
        dialogbox.setOnClickListener(bgclicklis);
        choice1.setOnClickListener(bclicklis);
        choice2.setOnClickListener(bclicklis);
    }

}
