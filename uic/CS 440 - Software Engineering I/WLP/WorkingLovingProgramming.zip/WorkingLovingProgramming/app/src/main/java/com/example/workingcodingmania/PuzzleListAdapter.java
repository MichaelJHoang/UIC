package com.example.workingcodingmania;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class PuzzleListAdapter extends BaseAdapter {
    private static final String TAG = "MailListAdapter";
    private final Context mContext;
    private ArrayList<Puzzle> puzzleArrayList;

    public PuzzleListAdapter(Context context, ArrayList<Puzzle> list) {
        this.mContext = context;
        puzzleArrayList = list;
    }

    @Override
    public int getCount()
    {
        return puzzleArrayList.size();
    }//end public int getCount

    @Override
    public Object getItem(int position)
    {
        return puzzleArrayList.get(position);
    }//end public Object getItem(int position)

    @Override
    public long getItemId(int position)
    {
        return 0;
    }//end public long getItemId

    @Override
    public View getView(int position, View view, ViewGroup parent)
    {

        View rowView = view;

        if (rowView == null)
            rowView= LayoutInflater.from(mContext).inflate(R.layout.list_item_puzzle, parent, false);

        Puzzle puzzle = puzzleArrayList.get(position);

        ImageView completionMark = rowView.findViewById(R.id.puzzle_row_imageview_complete_icon);
        TextView puzzleInfo = rowView.findViewById(R.id.textView_puzzle_row);

        String language = puzzle.language();
        String title = puzzle.title;
        String credibility = puzzle.currentCredibility + "/" + puzzle.initialCredibility;
        String strings;


        if (puzzle.isComplete)
        {

            completionMark.setImageResource(R.drawable.checkmark);
        }
        else
        {

            completionMark.setImageResource(R.drawable._empty);
        }

        strings = language + " " + title + ": " + credibility;
        puzzleInfo.setText(strings);

        /*
        ImageView senderIcon = (ImageView) rowView.findViewById(R.id.mail_row_imageview_sender_icon);

        senderIcon.setBackgroundResource(R.drawable._inventory_background);
        senderIcon.setImageResource(letter.senderWalkingID());

        TextView senderName = (TextView) rowView.findViewById(R.id.mail_row_textview_sendername);
        senderName.setText(letter.senderName());

        TextView sendDate = (TextView) rowView.findViewById(R.id.mail_row_textview_date);
        sendDate.setText(letter.dateSent());

        ImageView statusIcon = (ImageView) rowView.findViewById(R.id.mail_row_imageview_status);
        */


        return rowView;
    }

}//end public class PuzzleListAdapter extends BaseAdapter
