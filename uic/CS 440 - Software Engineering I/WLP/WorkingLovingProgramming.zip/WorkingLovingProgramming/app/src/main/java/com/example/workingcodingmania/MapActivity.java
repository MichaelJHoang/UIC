/*

    Author: Jon-Michael Hoang | jhoang6

 */

package com.example.workingcodingmania;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MapActivity extends AppCompatActivity
{
    public static final String TAG = "shin_MainActivity";
    //Media objects to play background music and sound effects
    protected MediaPlayer bgmPlayer;
    protected SoundPool sp;
    protected int[] soundIDs = new int[8];

    final private String savefilename = "s1";
    protected Map<String, Integer> defaultDialog = new HashMap<String, Integer>(){{
        put("office", R.raw.assembly);
        put("park", R.raw.python);
    }};

    int songIDs[] = {
            R.raw.einsteins_ribbon,
            R.raw.maemi_aaron_myhouse,
            R.raw.cafa_kikushima_ootayuki,
            R.raw.junya_nakanao_elfinforest,
            R.raw.ein_syabon
    };

    // shows the system bars by removing all the flags
    // except for the ones that make the content appear
    // under the system bars
    private void showSystemUI()
    {
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void hideSystemUI()
    {
        View decorView = getWindow().getDecorView();

        // enables regular immersive mode
        // for "lean back" mode, remove flag_immersive
        // or for sticky, replace with immersive_sticky
        decorView.setSystemUiVisibility(
                // set the content to appear under the system bars so
                // that the content does not resize when the system
                // bars hide and show
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // hide the nav and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        WindowManager.LayoutParams attr = getWindow().getAttributes();
        attr.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        getWindow().setAttributes(attr);
    }

    @Override
    public void onWindowFocusChanged (boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus)
            hideSystemUI();
    }

    TextView backgroundName;

    ImageView officephoto, cafephoto, parkphoto, barphoto;
    @Override
    protected void onCreate (Bundle savedInstance)
    {
        super.onCreate(savedInstance);
        setContentView(R.layout.maplayout);

        // readSaveFile();

        Transition fade = new Fade();
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);
        getWindow().setExitTransition(fade);
        getWindow().setEnterTransition(fade);

        officephoto = (ImageView)findViewById(R.id.officephoto);
        cafephoto = (ImageView)findViewById(R.id.cafephoto);
        parkphoto = (ImageView)findViewById(R.id.parkphoto);
        barphoto = (ImageView)findViewById(R.id.barphoto);

        // assign the text views
        backgroundName = (TextView)findViewById(R.id.adapterText);

        // save into the bundle the animations so that when the splash screen
        // transitions to the title screen,
        // the animation plays out smoothly
        final Bundle animationBundle = ActivityOptionsCompat.makeCustomAnimation(
                getApplicationContext(),
                android.R.anim.fade_in,
                android.R.anim.fade_out).toBundle();

        officephoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    Intent intent = new Intent (getApplicationContext(), shin_MainActivity.class);

                    intent.putExtra("backgroundImage", R.drawable.office3);
                    // intent.putExtra("fileid", R.raw.assembly);

                    startActivity(intent, animationBundle);
                }
                catch(ActivityNotFoundException e)
                {

                }
            }
        });

        cafephoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent (getApplicationContext(), shin_MainActivity.class);

                intent.putExtra("backgroundImage", R.drawable.cafe);

                startActivity(intent, animationBundle);
            }
        });

        parkphoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent (getApplicationContext(), shin_MainActivity.class);

                intent.putExtra("backgroundImage", R.drawable.afternoonpark);
                intent.putExtra("fileid", defaultDialog.get("park"));

                startActivityForResult(intent, 1 ,animationBundle);
            }
        });

        barphoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent (getApplicationContext(), shin_MainActivity.class);

                intent.putExtra("backgroundImage", R.drawable.bar);

                startActivity(intent, animationBundle);
            }
        });
    }

    public void clipboardButton(View v)
    {
        Intent intent = new Intent
                (getApplicationContext(), PuzzleCatalogActivity.class);
        startActivity(intent);
    }

    private String createSaveFile() {
        String offices = "office";
        String parks = "park";
        int officefid = defaultDialog.get(offices);
        int parkfid = defaultDialog.get(parks);

        String finalOffice = offices+";"+officefid+":";
        String finalPark = parks+";"+parkfid+":";

        String finalSave = finalOffice + finalPark;
        return finalSave;
    }

    private void writeSaveFile(String formattedSaveString) {
        try {
            FileOutputStream outputStream;
            outputStream = openFileOutput(savefilename, Context.MODE_PRIVATE);
            outputStream.write(formattedSaveString.getBytes());
            outputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readSaveFile() {
        try{
            FileInputStream inputStream;
            inputStream = openFileInput(savefilename);
            String input = "";
            int i;
            while((i = inputStream.read()) != -1) {
                input += (char)i;
            }
            String[] locations = input.split(":", defaultDialog.size());
            for (String a: locations) {
                String[] items = a.split(";",2);
                switch(items[0]) {
                    case "office":
                        defaultDialog.replace("office",Integer.parseInt(items[1].substring(0, items[1].length()-1)));
                        break;
                    case "park":
                        defaultDialog.replace("park",Integer.parseInt(items[1].substring(0, items[1].length()-1)));
                        break;
                    default:
                        break;
                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onStart()
    {
        Log.i(TAG, "In onStart");
        super.onStart();
        Random random = new Random();
        sp = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        soundIDs[0] = sp.load(this, R.raw.sfx_menu_decide, 1);
        soundIDs[1] = sp.load(this, R.raw.sfx_menu_decide_l, 1);
        soundIDs[2] = sp.load(this, R.raw.sfx_menu_decide_s, 1);
        soundIDs[3] = sp.load(this, R.raw.sfx_menu_decline, 1);
        soundIDs[4] = sp.load(this, R.raw.sfx_menu_finish, 1);
        soundIDs[5] = sp.load(this, R.raw.sfx_menu_highlight, 1);
        soundIDs[6] = sp.load(this, R.raw.sfx_puzzle_solution_incorrect, 1);
        soundIDs[7] = sp.load(this, R.raw.sfx_puzzle_solution_correct, 1);

        bgmPlayer = MediaPlayer.create(this,songIDs[random.nextInt(songIDs.length)]);
        bgmPlayer.setLooping(true);
        bgmPlayer.start();
    }//end protected void onStart()

    @Override
    protected void onPause()
    {
        Log.i(TAG, "In onPause");
        bgmPlayer.pause();
        super.onPause();
    }//end protected void onPause()

    @Override
    protected void onResume()
    {
        Log.i(TAG, "In onResume");
        super.onResume();
        bgmPlayer.seekTo(0);
        bgmPlayer.start();
    }//end protected void onResume()

    @Override
    protected void onStop()
    {
        Log.i(TAG, "In onStop");
        sp.release();
        sp = null;
        bgmPlayer.stop();
        bgmPlayer.reset();
        bgmPlayer.release();
        bgmPlayer = null;
        super.onStop();
    }//end protected void onStop()

    @Override
    protected void onDestroy()
    {
        Log.i(TAG, "In onDestroy");
        super.onDestroy();
    }//end protected void onDestroy()

    @Override
    protected void onActivityResult (int requestCode, int resultCode, Intent data) {
        boolean saveworthy = false;
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                int newfileid = data.getIntExtra("fid", 0);
                Log.i("MapActivity: " , " returned fid" + newfileid);
                defaultDialog.replace("park", newfileid);
                saveworthy = true;
            }
        }

        if (saveworthy == true) {
            writeSaveFile(createSaveFile());
        }
    }
}
