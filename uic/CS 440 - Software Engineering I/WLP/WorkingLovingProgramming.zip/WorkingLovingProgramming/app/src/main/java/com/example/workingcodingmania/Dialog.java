package com.example.workingcodingmania;

import java.util.ArrayList;

public class Dialog {
    public String title;
    public static int id = 0;

    public String charname;
    public String charImg;
    public ArrayList<DialogText> textList;
}
