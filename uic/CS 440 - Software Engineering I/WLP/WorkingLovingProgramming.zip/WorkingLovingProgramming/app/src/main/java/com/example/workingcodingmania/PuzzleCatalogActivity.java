package com.example.workingcodingmania;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Transition;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PuzzleCatalogActivity extends AppCompatActivity {

    public static final String TAG = "PuzzleCatalogActivity";
    private static final int REPLAY = 100, CANCEL = 101;
    TextView credibilityRating, numPuzzles_textView,cppRating_textView, assemblyRating_textView, pythonRating_textView, sqlRating_textView, javaRating_textView, cRating_textView;

    private ListView listView;
    PuzzleListAdapter puzzleListAdapter;
    Puzzle_Catalog puzzleCatalog;
    Puzzle puzzle;
    //Media objects to play background music and sound effects
    protected MediaPlayer bgmPlayer;
    protected SoundPool sp;
    protected int[] soundIDs = new int[8];

    // shows the system bars by removing all the flags
    // except for the ones that make the content appear
    // under the system bars
    private void showSystemUI()
    {
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void hideSystemUI()
    {
        View decorView = getWindow().getDecorView();

        // enables regular immersive mode
        // for "lean back" mode, remove flag_immersive
        // or for sticky, replace with immersive_sticky
        decorView.setSystemUiVisibility(
                // set the content to appear under the system bars so
                // that the content does not resize when the system
                // bars hide and show
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // hide the nav and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        WindowManager.LayoutParams attr = getWindow().getAttributes();
        attr.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        getWindow().setAttributes(attr);
    }

    @Override
    public void onWindowFocusChanged (boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus)
            hideSystemUI();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.i(TAG, "In onCreate");

        super.onCreate(savedInstanceState);

        setTheme(R.style.AppTheme);
        setContentView(R.layout.activity_puzzle_catalog);

        Transition fade = new Fade();
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);
        getWindow().setExitTransition(fade);
        getWindow().setEnterTransition(fade);

        credibilityRating = findViewById(R.id.textView_overallCredibility);
        numPuzzles_textView = findViewById(R.id.textView_puzzlesSolved);
        cppRating_textView = findViewById(R.id.textView_cppRating);
        assemblyRating_textView = findViewById(R.id.textView_assemblyRating);
        pythonRating_textView = findViewById(R.id.textView_pythonRating);
        sqlRating_textView = findViewById(R.id.textView_sqlRating);
        cRating_textView = findViewById(R.id.textView_cRating);
        javaRating_textView = findViewById(R.id.textView_javaRating);

        puzzleCatalog = new Puzzle_Catalog();
        init();

        puzzleListAdapter = new PuzzleListAdapter(this, puzzleCatalog.puzzleArrayList);
        updateDisplay();

        listView = (ListView) findViewById(R.id.listview_puzzleList);
        listView.setAdapter(puzzleListAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                puzzle = puzzleCatalog.puzzleArrayList.get(position);

                //Don't create popup menu if there is no letter
                if (puzzle == null)
                    return;

                //Play submenu open sfx
               // sp.play(soundIDs[15], 1, 1, 1, 0, 1);
                PopupMenu popup = new PopupMenu(getApplicationContext(), view, Gravity.CENTER);

                if (puzzle.isComplete)
                    popup.getMenu().add(0, REPLAY, 0, "Replay");
                popup.getMenu().add(0, CANCEL, 0, "Cancel");

                /** Defining menu item click listener for the popup menu */
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener()
                {

                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();


                        switch (item.getItemId())
                        {
                            case REPLAY:
                                //sp.play(soundIDs[13], 1, 1, 1, 0, 1);
                                Intent intent = new Intent
                                        (getApplicationContext(), PuzzleActivity.class);
                                intent.putExtra("PUZZLE_ID", puzzle.puzzleID);
                                startActivity(intent);
                                return true;

                            default:
                                //sp.play(soundIDs[4], 1, 1, 1, 0, 1);
                                updateDisplay();
                                return true;
                        }//end switch (item.getItemId())
                    }//end public boolean onMenuItemClick(MenuItem item)
                });//end public boolean onMenuItemClick(MenuItem item)

                /** Showing the popup menu */

                popup.show();
            }//end public void onItemClick(AdapterView<?> parent, View view, int position, long id)


        });//end new AdapterView.OnItemClickListener()
    }//end protected void onCreate(Bundle savedInstanceState)

    @Override
    protected void onStart()
    {
        Log.i(TAG, "In onStart");
        super.onStart();
        sp = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        soundIDs[0] = sp.load(this, R.raw.sfx_menu_decide, 1);
        soundIDs[1] = sp.load(this, R.raw.sfx_menu_decide_l, 1);
        soundIDs[2] = sp.load(this, R.raw.sfx_menu_decide_s, 1);
        soundIDs[3] = sp.load(this, R.raw.sfx_menu_decline, 1);
        soundIDs[4] = sp.load(this, R.raw.sfx_menu_finish, 1);
        soundIDs[5] = sp.load(this, R.raw.sfx_menu_highlight, 1);
        soundIDs[6] = sp.load(this, R.raw.sfx_puzzle_solution_incorrect, 1);
        soundIDs[7] = sp.load(this, R.raw.sfx_puzzle_solution_correct, 1);

        bgmPlayer = MediaPlayer.create(this,R.raw.music_theme_puzzle);
        bgmPlayer.setLooping(true);
        bgmPlayer.start();
    }//end protected void onStart()

    @Override
    protected void onPause()
    {
        Log.i(TAG, "In onPause");
        bgmPlayer.pause();
        super.onPause();
    }//end protected void onPause()

    @Override
    protected void onResume()
    {
        Log.i(TAG, "In onResume");
        super.onResume();
        bgmPlayer.seekTo(0);
        bgmPlayer.start();
    }//end protected void onResume()

    @Override
    protected void onStop()
    {
        Log.i(TAG, "In onStop");
        sp.release();
        sp = null;
        bgmPlayer.stop();
        bgmPlayer.reset();
        bgmPlayer.release();
        bgmPlayer = null;
        super.onStop();
    }//end protected void onStop()

    @Override
    protected void onDestroy()
    {
        Log.i(TAG, "In onDestroy");
        super.onDestroy();
    }//end protected void onDestroy()


    public Puzzle initPuzzle(int stringArrayID)
    {

        Puzzle puzzle;   //Puzzle data from XML is stored here
        int puzzleID;    //Puzzle ID (string-array ID from XML)
        int puzzleType; //0 - Fill in the blanks, 1 - output, 2 - spot the error
        String puzzleInfo[] = getResources().getStringArray(stringArrayID);

        puzzleType = Integer.parseInt(puzzleInfo[0]);
        if (puzzleType == 0)
        {
            puzzle = new Puzzle_FillInTheCode();
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[0] = puzzleInfo[7];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[1] = puzzleInfo[8];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[2] = puzzleInfo[9];
            ((Puzzle_FillInTheCode)puzzle).possibleSlns[3] = puzzleInfo[10];
        }
        else
        {
            puzzle = new Puzzle_MultiChoice();
            ((Puzzle_MultiChoice) puzzle).optionA = puzzleInfo[7];
            ((Puzzle_MultiChoice) puzzle).optionB = puzzleInfo[8];
            ((Puzzle_MultiChoice) puzzle).optionC = puzzleInfo[9];
            ((Puzzle_MultiChoice) puzzle).optionD = puzzleInfo[10];
            ((Puzzle_MultiChoice) puzzle).solution_index = Integer.parseInt(puzzleInfo[11]);
        }

        puzzle.puzzleID = stringArrayID;
        puzzle.title = puzzleInfo[1];
        puzzle.description = puzzleInfo[2];
        puzzle.code = puzzleInfo[3];
        puzzle.hint = puzzleInfo[4];
        puzzle.explanation = puzzleInfo[5];
        puzzle.initialCredibility = Integer.parseInt(puzzleInfo[6]);
        puzzle.currentCredibility = puzzle.initialCredibility;

        return puzzle;
    }//end public void initPuzzle(int stringArrayID)

    private void updateDisplay()
    {
        String puzzlesSolved = puzzleCatalog.puzzlesSolved + "/" + puzzleCatalog.puzzlesFound;
        String credibility = Integer.toString(puzzleCatalog.credibility);
        String cppRating = "C++: " +Integer.toString(puzzleCatalog.cppCredibility);
        String pythonRating = "Python: "+ Integer.toString(puzzleCatalog.pythonCredibility);
        String assemblyRating = "Assembly: " + Integer.toString(puzzleCatalog.assemblyCredibility);
        String sqlRating = "SQL: " + Integer.toString(puzzleCatalog.sqlCredibility);

        String cRating = "C: " + Integer.toString(puzzleCatalog.cCredibility);
        String javaRating = "Java: " + Integer.toString(puzzleCatalog.javaCredibility);
        credibilityRating.setText(credibility);
        numPuzzles_textView.setText(puzzlesSolved);
        cppRating_textView.setText(cppRating);
        pythonRating_textView.setText(pythonRating);
        assemblyRating_textView.setText(assemblyRating);
        sqlRating_textView.setText(sqlRating);
        cRating_textView.setText(cRating);
        javaRating_textView.setText(javaRating);

    }//end private void updateDisplay()

    private void init()
    {
        Puzzle[] p = new Puzzle[13];
        p[0] = initPuzzle(R.array.Puzzle10);
        p[1] = initPuzzle(R.array.Puzzle12);
        p[2] = initPuzzle(R.array.Puzzle20);
        p[3] = initPuzzle(R.array.Puzzle21);
        p[4] = initPuzzle(R.array.Puzzle22);
        p[5] = initPuzzle(R.array.Puzzle23);
        p[6] = initPuzzle(R.array.Puzzle24);
        p[7] = initPuzzle(R.array.Puzzle30);
        p[8] = initPuzzle(R.array.Puzzle40);
        p[9] = initPuzzle(R.array.Puzzle41);
        p[10] = initPuzzle(R.array.Puzzle42);
        p[11] = initPuzzle(R.array.Puzzle43);
        p[12] = initPuzzle(R.array.Puzzle44);

        Puzzle[] test = new Puzzle[10];
        test[0] = initPuzzle(R.array.Puzzle10);
        test[0].title = "Puzzle 13";
        test[0].currentCredibility = test[0].initialCredibility/2;

        test[1] = initPuzzle(R.array.Puzzle12);
        test[1].title = "Puzzle 16";
        test[1].initialCredibility*=3;
        test[1].currentCredibility = test[1].initialCredibility;

        test[2] = initPuzzle(R.array.Puzzle12);
        test[2].title = "Puzzle 25";
        test[2].currentCredibility = (int)(test[2].initialCredibility * ((double)3/4));

        test[3] = initPuzzle(R.array.Puzzle12);
        test[3].title = "Puzzle 31";
        test[3].initialCredibility*=2;
        test[3].currentCredibility = (int)(test[3].initialCredibility * ((double)3/4));

        test[4] = initPuzzle(R.array.Puzzle10);
        test[4].title = "Puzzle 45";
        test[4].currentCredibility = (test[4].initialCredibility/ 2);

        test[5] = initPuzzle(R.array.Puzzle10);
        test[5].initialCredibility*=2;
        test[5].title = "Puzzle 53";
        test[5].currentCredibility = (int)(test[5].initialCredibility * ((double)3/4));

        test[6] = initPuzzle(R.array.Puzzle12);
        test[6].title = "Puzzle 60";
        test[6].initialCredibility/=2;
        test[6].currentCredibility = test[6].initialCredibility;

        test[7] = initPuzzle(R.array.Puzzle12);
        test[7].title = "Puzzle 61";
        test[7].initialCredibility*=3;
        test[7].currentCredibility = test[7].initialCredibility;

        for (int i = 0; i < p.length; i++) {
            p[i].isComplete = true;
            puzzleCatalog.puzzleArrayList.add(p[i]);
        }
        puzzleCatalog.puzzleArrayList.add(test[0]);
        puzzleCatalog.puzzleArrayList.add(test[1]);
        puzzleCatalog.puzzleArrayList.add(test[2]);
        puzzleCatalog.puzzleArrayList.add(test[3]);
        puzzleCatalog.puzzleArrayList.add(test[4]);
        puzzleCatalog.puzzleArrayList.add(test[5]);
        puzzleCatalog.puzzleArrayList.add(test[6]);
        puzzleCatalog.puzzleArrayList.add(test[7]);
        puzzleCatalog.updateInfo();
    }
}//end public class PuzzleCatalogActivity extends AppCompatActivity
