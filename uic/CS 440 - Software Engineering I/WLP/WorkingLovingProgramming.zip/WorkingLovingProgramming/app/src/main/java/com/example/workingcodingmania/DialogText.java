package com.example.workingcodingmania;

public class DialogText {
    private String text;
    private static int id = 0;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getTextType() {
        return 1;
    }

    public String getNextContent() {
        return text;
    }
}

