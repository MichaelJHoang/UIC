/*

    Author: Jon-Michael Hoang | jhoang6

 */

package com.example.workingcodingmania;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Random;

public class TitleScreenActivity extends AppCompatActivity
{
    // array filled with all the background references
    int imageID[] = {
            R.drawable.afternoonpark,
            R.drawable.cafe,
            R.drawable.bar,
            R.drawable.office,
            R.drawable.office2,
            R.drawable.office3,
            R.drawable.trainstation
    };

    int songIDs[] = {
            R.raw.einsteins_ribbon,
            R.raw.maemi_aaron_myhouse,
            R.raw.cafa_kikushima_ootayuki,
            R.raw.junya_nakanao_elfinforest,
            R.raw.ein_syabon
    };

    // shows the system bars by removing all the flags
    // except for the ones that make the content appear
    // under the system bars
    private void showSystemUI()
    {
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void hideSystemUI()
    {
        View decorView = getWindow().getDecorView();

        // enables regular immersive mode
        // for "lean back" mode, remove flag_immersive
        // or for sticky, replace with immersive_sticky
        decorView.setSystemUiVisibility(
                // set the content to appear under the system bars so
                // that the content does not resize when the system
                // bars hide and show
                View.SYSTEM_UI_FLAG_IMMERSIVE
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                // hide the nav and status bar
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        WindowManager.LayoutParams attr = getWindow().getAttributes();
        attr.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        getWindow().setAttributes(attr);
    }

    @Override
    public void onWindowFocusChanged (boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus)
            hideSystemUI();
    }


    Button gameStartButton;
    RelativeLayout relativeLayout;

    private Random random = new Random();
    //private final int fixedRandom = random.nextInt(imageID.length);

    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // necessities to make the view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.titlescreenlayout);

        // grab the background reference
        relativeLayout = findViewById(R.id.mainActivityLayout);

        // each time the application is created, a different background is loaded
        relativeLayout.setBackgroundResource(imageID[random.nextInt(imageID.length)]);

        Transition fade = new Fade();
        fade.excludeTarget(android.R.id.statusBarBackground, true);
        fade.excludeTarget(android.R.id.navigationBarBackground, true);
        getWindow().setExitTransition(fade);
        getWindow().setEnterTransition(fade);

        // save into the bundle the animations so that when the splash screen
        // transitions to the title screen,
        // the animation plays out smoothly
        final Bundle bundle = ActivityOptionsCompat.makeCustomAnimation(
                getApplicationContext(),
                android.R.anim.fade_in,
                android.R.anim.fade_out).toBundle();


        mediaPlayer = MediaPlayer.create(getApplicationContext(), songIDs[random.nextInt(songIDs.length)]);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();


        // set a listener on the background such that when tapped,
        // leads the user to the map activity
        relativeLayout.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v)
            {
                try
                {
                    Intent intent = new Intent(TitleScreenActivity.this, MapActivity.class);

                    Log.i("TitleScreenActivity.java", "The screen has been tapped");

                    startActivity(intent, bundle);

                    finish();
                }
                catch (ActivityNotFoundException e)
                {
                }
            }
        });

        // manipulate the textview to fade in and out
        final TextView tapToStartText = findViewById(R.id.tapToStartButton);

        // manipulate how it fades in and out
        final Animation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(750);
        fadeIn.setStartOffset(750);

        final Animation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setDuration(750);
        fadeOut.setStartOffset(750);

        // animation listeners to make it loop over and over
        try
        {
            fadeIn.setAnimationListener(new Animation.AnimationListener()
            {
                @Override public void onAnimationStart(Animation animation) {}

                @Override
                public void onAnimationEnd(Animation animation) {
                    tapToStartText.startAnimation(fadeOut);
                }

                @Override public void onAnimationRepeat(Animation animation) {}
            });

            fadeOut.setAnimationListener(new Animation.AnimationListener() {
                @Override public void onAnimationStart(Animation animation) {}

                @Override
                public void onAnimationEnd(Animation animation) {
                    tapToStartText.startAnimation(fadeIn);
                }

                @Override public void onAnimationRepeat(Animation animation) {}
            });

            tapToStartText.startAnimation(fadeOut);
        }
        catch (ActivityNotFoundException e)
        {
        }

        // set a listener on the text view such that when tapped,
        // leads the user to the map activity
        // reason being so is that the text view is independent-ish from the
        // relative layout because it needs the animation
        tapToStartText.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    Intent intent = new Intent(TitleScreenActivity.this, MapActivity.class);

                    Log.i("TitleScreenActivity.java", "The screen has been tapped");

                    startActivity(intent, bundle);

                    finish();
                }
                catch (ActivityNotFoundException e)
                {
                }
            }
        });
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if (mediaPlayer.isPlaying())
        {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }
}
