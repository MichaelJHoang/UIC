package com.example.workingcodingmania;

/////////////////////////////////////////////////////////////////////////////////////////////
//								Working, Loving, Programming								//
/////////////////////////////////////////////////////////////////////////////////////////////
//	Type of Program:				Game						            				//
//	File Author:					Jeremy Robles											//
//	File Name:						Puzzle_MultiChoice.java									//
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////
//																							//
/////////////////////////////////////////////////////////////////////////////////////////////

public class Puzzle_MultiChoice extends Puzzle {
    int stringID_optionA,   //string IDs of the different options
        stringID_optionB,
        stringID_optionC,
        stringID_optionD,
        solution_index;     //Correct solution index (0-A, 1-B, 2-C, 3-D)

    String optionA, optionB, optionC, optionD; //Strings of the options

}//end public class Puzzle_MultiChoice extends Puzzle
