/*
 * Author: Jon-Michael Hoang | jhoang6
 * 
 * This file contains a class that generates a hash code
 * based on the number of characters within the room and
 * the sum of their luck.
 * 
 * But little did they know...high luck plays against them.
 * 
 * Considerations:
 * 	- shorter hash code?
 * 	- prove the algorithm
 */

import java.util.*;

public class Event 
{
	private int totalLuck;
	private int weight;
	private Random rand;
	
	public Event (ArrayList<Character> characterList)
	{
		for (Character iter : characterList)
			totalLuck = iter.luck();
		
		weight = characterList.size();
		
		rand = new Random();
	}
	
	// based off of Daniel J. Bernstein's hashing thing
	// return a rather complex-that-I-don't-even-understand RNG value
	public int getRNG ()
	{
		// not sure what numbers this will produce, but oh well.
		int hash = 5381;
		
		int temp = rand.nextInt(weight); 
		
		temp += (temp == 0) ? 1 : 0;	// don't want to divide by zero
		
		// (x % weight) != 0 .. could that work otherwise?
		for (int x = (totalLuck << weight) / temp; (x % 2) != 0; x += rand.nextInt())
		{
			hash <<= 5;
			hash += hash;
		}
		
		rand = new Random();
		
		return Math.round(hash * (rand.nextFloat() * weight));
	}
	
	public int getRNG_light ()
	{
		return rand.nextInt(9);
	}
}
