// Author: Jon-Michael Hoang

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GUI_2 extends JFrame implements UserInterface, ActionListener
{
	// labels
	private JLabel inputLabel;
	private JLabel imageLabel;
	
	// buttons
	private JButton executeButton;
	
	// fields
	private JTextField textField;
	
	// area
	private JTextArea textArea;
	
	// other variables
	private String buffer;
	private boolean moveMade = false;
	
	private boolean flag = false;
	
	public GUI_2 (String string)
	{
		setLayout(new FlowLayout());
		
		imageLabel = new JLabel();
		
		imageLabel.setIcon(new ImageIcon(flag ? "noob.gif" : "SwordStone.jpg"));
		add(imageLabel);
		
		inputLabel = new JLabel ("Input: ");
		add(inputLabel);
		
		textField = new JTextField(20);
		add(textField);
		
		executeButton = new JButton ("Execute");
		add(executeButton);
		executeButton.addActionListener(this);
		
		executeButton = new JButton ("Instructions");
		add(executeButton);
		executeButton.addActionListener(this);
		
		executeButton = new JButton (flag ? "COMMIT BIG OOF" : "Exit");
		add(executeButton);
		executeButton.addActionListener(this);
		
		textArea = new JTextArea ("- - - - - - - - - - Event Log: - - - - - - - - - - \n", 30, 60);
		
		JScrollPane scrollPane = new JScrollPane (textArea);
		
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		
		getContentPane().add(scrollPane);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 1000);
		setTitle(string);
		setVisible(true);
		
		buffer = "DEFAULT";
		
		pack();
	}
	
	@Override
	public void display (String string)
	{
		textArea.append(string + "\n----------------------------------------------------------------------------------------------------\n");
		textArea.setCaretPosition(textArea.getDocument().getLength());
	}
	
	@Override
	public String getLine()
	{
		this.setVisible(true);
		
		moveMade = false;
		
		while (!this.moveMade)
		{
			try
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
		this.setVisible(false);
		
		return buffer;
	}
	
	@Override
	public void actionPerformed (ActionEvent e)
	{
		if (e.getActionCommand().equalsIgnoreCase("EXECUTE"))
		{
			if (textField.getText().equalsIgnoreCase("TOGGLE EASTER EGG"))
			{
				flag = (flag == true) ? false : flag;
			}
			else if (textField.getText() != "")
			{
				this.buffer = textField.getText();
				this.moveMade = true;
			}
			
		}
		else if (e.getActionCommand().equalsIgnoreCase("INSTRUCTIONS"))
		{
			this.buffer = "CMD";
			this.moveMade = true;
		}
		else if (e.getActionCommand().equalsIgnoreCase(flag ? "COMMIT BIG OOF" : "Exit"))
		{
			this.buffer = "EXIT";
			this.moveMade = true;
		}
		
		textField.setText("");
		
		return;
	}
}