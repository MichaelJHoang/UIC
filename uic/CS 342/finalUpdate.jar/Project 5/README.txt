Group: 51
Members:
	Dilip Vemuri - dvemuri3
	Jon-Michael Hoang - jhoang6
	Franky Zhang - xzhan40
	
Homework 4

General Info: 
	The program runs on gdf file format 5.1 , we included a test file in our 
	submission. The documentation of the file is properly kept in the included
	GDF File Format word document. The program will run with the test file. The
	Program IS NOT BACKWARDS COMPATIBLE. At startup, the program can take up to
	two command line arguments. Argument 1 is the filename, argument 2 is the
	number of players you want. Anymore than 2 the player exits. 0 commandline
	arguments asks the user for a file name.
	
	When the game runs, you will have a chance to control every player character for
	a turn. A list of commands is given by typing CMD when it's a players turn. For now
	All commands must be given in CAPS lock, i.e LOOK , INVENTORY, EXIT etc. Typing exit
	will remove a singular character. Typing QUIT will exit the program. The player can attack
	other players, generic NPCs and Ogres. Cannot Attack merchants and dogs. Players can recieve
	damage and die of fatal wounds.

	The game defaults to text interface. Type GUI #, # being a number between 0-3, 0 being textinterface
	1 being Dilips GUI
	2 being Jon-Michael's
	3 being Franky's
	
	
Dilip Vemuri:
	-Added the IO, UI, TextInterface and GUI1 classes. 
	- Cleaned up character class and made output during the game cleaner
	- made it so the user can input lower and uppercase commands
	- Implemented GUI 1.
	- Got rid of redundancies with the character variables and unused ones
	- cleaned up some uneeded methods and move them to parent/child classes as appropriate 
Franky Zhang:	
	-Implemented GUI 3.
	-Helped with IO.

Jon-Michael Hoang:
	-Implemented GUI 2.
	-Reworked the EventPlace and classes related to it a bit to ensure compatibility
	-Added a couple of events
	-Added some things to IO
	-Updated the UML diagram
