
import java.util.Scanner;

public class TextInterface implements UserInterface {

	@Override
	public void display(String s) {
		System.out.println(s);

	}

	@Override
	public String getLine() {
		return KeyboardScanner.getKeyboardScanner().nextLine();
	}

}
