import java.awt.*;
import javax.swing.*;

import java.awt.event.*;
import java.io.*;
public class GUI_3 extends JFrame implements UserInterface , ActionListener {
	private JLabel label;
	private JTextField tf;
	private JTextArea ta;
	private JButton button;
	
	private String buffer;
	private boolean moveMade;
	
	public GUI_3(String s) {
		
		setLayout(new FlowLayout());
		
		button = new JButton("GO");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("GET");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("DROP");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("EQUIPA");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("EQUIPW");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("CMD");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("LOOK");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("WAIT");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("USE");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("INVENTORY");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("TRADE");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("PET");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("ATTACK");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("EXIT");
		add(button);
		button.addActionListener(this);
		
		button = new JButton("GUI");
		add(button);
		button.addActionListener(this);
		
		
		label = new JLabel("Enter Move: ");
		add(label);
		
		tf = new JTextField(30);
		add(tf);
		
		label = new JLabel();
		label.setIcon(new ImageIcon("Compass.jpg"));
		add(label);
		
		ta = new JTextArea("Game Status:\n",40, 60);
		JScrollPane scrollPane = new JScrollPane(ta);
		ta.setEditable(false);
		ta.setLineWrap(true);
		getContentPane().add(scrollPane);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 600);
		setTitle(s);
		setVisible(true);
		
		buffer = "default";
		moveMade = false;
		pack();
	}

	
	@Override
	public void display(String s) {
		
		ta.append(s +"\n");
		ta.setCaretPosition(ta.getDocument().getLength());
	}

	@Override
	public String getLine() {
		this.setVisible(true);
		moveMade = false;
		while( !this.moveMade) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.setVisible(false);
		return buffer;
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		this.buffer = e.getActionCommand();
		this.buffer += " "+ tf.getText();
		this.moveMade = true;		
		tf.setText("");
		return;
	}

	
}
