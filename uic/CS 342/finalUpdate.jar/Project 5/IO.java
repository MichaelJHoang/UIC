/*Dilip Vemuri
 * Homework 5
 */

public class IO {
	
	public static final int TEXT = 0;
	public static final int GUI_1 = 1;
	public static final int GUI_2 = 2;
	public static final int GUI_3 = 3;
	UserInterface implementor;
	
	
	public IO(String s){
		// default to text
		//implementor = new TextInterface();
		implementor = new TextInterface();
	}
	
	public void display(String s) {
		implementor.display(s);
	}
	
	public String getLine() {
		//System.out.println("USING IO");
		return implementor.getLine();
	}
	
	public void selectInterface(int i, Character c) {
		if( i == 0) {
			implementor = new TextInterface();
		}
		else if( i == 1) {
			implementor = new GUI_1(c.name());
			
		}
		else if( i == 2) {
			implementor = new GUI_2(c.name());
		}
		else if (i == 3) {
			implementor = new GUI_3(c.name());
		}
		
		else
			return;
		
	}

}
