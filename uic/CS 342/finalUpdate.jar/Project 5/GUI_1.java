/*Dilip Vemuri
 * Homework 5
 */

import java.awt.*;
import javax.swing.*;

import java.awt.event.*;
import java.io.*;



public class GUI_1 extends JFrame implements UserInterface , ActionListener {
	
	private JLabel label;
	private JTextField tf;
	private JTextArea ta ;
	private JButton button;
	//private JFrame test;
	
	private String buffer;
	private boolean moveMade;
	
	public GUI_1(String s) {
		
		setLayout(new FlowLayout());
		
		label = new JLabel("Enter Move: ");
		add(label);
		
		tf = new JTextField(10);
		add(tf);

		button = new JButton("DONE");
		add(button);		
		button.addActionListener(this);
		
		
		ta = new JTextArea("Game Status:\n",30, 60);
		JScrollPane scrollPane = new JScrollPane(ta);
		ta.setEditable(false);
		ta.setLineWrap(true);
		//test.add(ta);
		getContentPane().add(scrollPane);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 300);
		setTitle(s);
		setVisible(true);
		
		buffer = "default";
		moveMade = false;
		pack();
	}
	
	@Override
	public void display(String s) {		
		ta.append(s +"\n");
		ta.setCaretPosition(ta.getDocument().getLength());
	}
	
	@Override
	public String getLine() {
		this.setVisible(true);
		this.requestFocus();
		moveMade = false;
		while( !this.moveMade) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.setVisible(false);
		return buffer;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		this.buffer = tf.getText();
		this.moveMade = true;		
		tf.setText("");
		
		return;
	}
	
	
}
