/*Name: Dilip Vemuri
 * NETID: Dvemuri3
 * implements DecisionMaker
 * Right now this is a dummy class, it does nothing.
 */

public class MerchantAI implements DecisionMaker{

	@Override
	public Move getMove(Character c, Place p) {
		//Merchants cannot do anything without the character interacting with them yet
		return null;
	}

}
