module Set

#light

//
// returns true if set S is empty [], false if not
// 
let rec isEmpty S = 
  match S with
  | [] -> true
  | _::rest -> false && isEmpty rest

//
// returns true if x is in S, false if not
// 
let rec isMember x S = 
  match S with
  | [] -> false
  | e::_ when e = x -> true
  | _::rest -> (isMember x rest)

//
// returns the # of elements in the set
//
let rec size S = 
  match S with
  | [] -> 0
  | _::rest -> 1 + size rest

//
// inserts x into S, returning the new set S'
// 
// NOTE #1: elements are inserted in order using <.
// NOTE #2: if x exists in S, then S is returned unchanged.
// 
let rec insert x S = 
  match S with
  | [] -> [x]
  | e::rest when (not (e<x)) && (not (x<e)) -> S
  | e:: rest -> if x < e then
                 (x::e::rest)
                else
                 e::(insert x rest)

//
// removes x from S, returning the new set S'
// 
// NOTE: if x is not in S, then S is returned unchanged.
//

// function to determine equality
let private _equal a b = 
 (not (a < b)) && (not (b < a))

let rec _remove x S newSet = 
  match S with
  | [] -> newSet
  | e::rest when _equal e x -> newSet @ rest
  | e::rest -> _remove x rest (newSet @ [e])

let rec remove x S = 
  _remove x S []

//
// returns true is A is a subset of B, false if not
//

let rec contains x L = 
  match L with
  | [] -> false
  | e::_ when e = x -> true
  | _::rest -> (contains x rest)

let rec subset A B = 
  match A, B with
  | [], [] -> true
  | [], _ -> true
  | _, [] -> false
  | hd1::t1, _ -> (contains hd1 B) && (subset A B)

// 
// returns true if A and B contain the same elements,
// false if not
//
let rec equivalent A B = 
  match A, B with
  | [], [] -> true
  | [], _ -> false
  | _, [] -> false
  | e1::rest1, e2::rest2 -> e1 = e2 && equivalent rest1 rest2

//
// returns A union B
// 
// Example:
//   A = [1;2;3;4]
//   B = [2;5;6]
//   ==> [1;2;3;4;5;6]
//

let rec union A B = 
  match A, B with
  | [], [] -> []
  | _, [] -> A
  | [], _ -> B
  | e::rest, B -> if (isMember e B) then
                   union rest B
                  else
                   union rest (insert e B)
  
//
// returns A intersect B
// 
// Example:
//   A = [1;2;3;4]
//   B = [2;4]
//   ==> [2;4]
//
let rec intersection A B = 
  match A with
  | [] -> []
  | e::rest when (isMember e B) -> e::(intersection rest B)
  | e::rest -> (intersection rest B)

//
// returns A - B
// 
// Example:
//   A = [1;2;3;4]
//   B = [2;4]
//   ==> [1;3]
//   
let rec difference A B = 
  match A, B with
  | [], [] -> []
  | _, [] -> A
  | [], _ -> B
  | A, e::rest -> if (isMember e A) then
                   difference (remove e A) rest
                  else
                   difference A rest

// 
// returns the cartesian product of A and B:
// 
// Example:
//   A = [1;2]
//   B = [3;4]
//   ==> [ [1;3]; [1;4]; [2;3]; [2;4] ]
// 

// there was an attempt.
let _product a B = 
  match a, B with
  | a, [] -> []
  | a, b::rest -> [a; b]

let rec product A B = 
  match A, B with
  | _, [] -> [[]]
  | [], _ -> [[]]
  | ea::resta, B -> _product ea B

// 
// returns the set containing all possible subsets:
// 
// Example:  
//   S = [1;2;3]
//   ==> [ []; [1]; [2]; [3]; [1;2]; [1;3]; [2;3]; [1;2;3] ]
//
let rec powerset S = 
  []
