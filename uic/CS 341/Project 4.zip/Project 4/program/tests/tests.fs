module Tests

#light

open System
open Microsoft.VisualStudio.TestTools.UnitTesting

[<TestClass>]
type TestClass () =

  [<TestMethod>]
  member this.isEmpty_T01 () =
    let expected = true
    let actual = Set.isEmpty []
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.isEmpty_T02 () =
    let expected = false
    let actual = Set.isEmpty [1;2;3]
    Assert.AreEqual(expected, actual)

  [<TestMethod>]
  member this.isMember_T01 () =
    let expected = true
    let actual = Set.isMember "cat" ["apple";"cat";"dog"]
    Assert.AreEqual(expected, actual) 
    
  [<TestMethod>]
  member this.isMember_T02 () =
    let expected = false
    let actual = Set.isMember 4 [1;2;3]
    Assert.AreEqual(expected, actual) 

  [<TestMethod>]
  member this.isMember_T03 () =
    let expected = false
    let actual = Set.isMember "apple" []
    Assert.AreEqual(expected, actual) 
    
  [<TestMethod>]
  member this.insert_T01 () =
    let expected = [1]
    let actual = Set.insert 1 []
    Assert.AreEqual(expected, actual) 
    
  [<TestMethod>]
  member this.insert_T02 () =
    let expected = [1;2;3]
    let actual = Set.insert 2 [1;3]
    Assert.AreEqual(expected, actual) 

  [<TestMethod>]
  member this.insert_T03 () =
    let expected = ["apple";"cat";"dog"]
    let actual = Set.insert "cat" ["apple";"dog"]
    Assert.AreEqual(expected, actual) 
    
  [<TestMethod>]
  member this.union_T03 () =
    let expected = [1;2;3]
    let actual = Set.union [1;2] [2;3]
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.intersection_T01 () =
    let expected = [1;2]
    let actual = Set.intersection [1; 2; 3] [1;2]
    Assert.AreEqual(expected, actual) 
    
  [<TestMethod>]
  member this.subset_T02 () =
    let expected = false
    let actual = Set.subset [1; 2; 3] []
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.equivalent_T02 () =
    let expected = false
    let actual = Set.equivalent [] [1]
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.equivalent_T01 () =
    let expected = true
    let actual = Set.equivalent [1;2;3] [1;2;3]
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.difference_T01 () = 
    let expected = [1;3]
    let actual = Set.difference [1;2;3;4] [2;4]
    Assert.AreEqual(expected, actual)
    
  [<TestMethod>]
  member this.product_T01 () = 
    let expected = [ [1;3]; [1;4]; [2;3]; [2;4] ]
    let actual = Set.product [[1;2]] [[3;4]]
    Assert.AreEqual(expected, actual)